webpackHotUpdate_N_E("pages/index",{

/***/ "./pages/index.tsx":
/*!*************************!*\
  !*** ./pages/index.tsx ***!
  \*************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return Home; });
/* harmony import */ var C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _roomservice_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @roomservice/react */ "./node_modules/@roomservice/react/dist/react.esm.js");


var _jsxFileName = "C:\\Glenn\\JS\\roomservice\\examples-master\\next.js-minimal\\pages\\index.tsx",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_1___default.a.createElement;

function Home() {
  _s();

  var _useMap = Object(_roomservice_react__WEBPACK_IMPORTED_MODULE_2__["useMap"])("myindex", "home"),
      _useMap2 = Object(C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_0__["default"])(_useMap, 2),
      form = _useMap2[0],
      map = _useMap2[1];

  return __jsx("div", {
    className: "intro-container",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 5
    }
  }, __jsx("p", {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }
  }, "This is a minimal Next.js example with Room Service. It follows the", " ", __jsx("a", {
    href: "https://roomservice.dev/docs/react-getting-started",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 9
    }
  }, "guide here.")), __jsx("br", {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }
  }), __jsx("label", {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 7
    }
  }, "Load Tree", __jsx("input", {
    value: form.treeId,
    onChange: function onChange(e) {
      return map === null || map === void 0 ? void 0 : map.set("trseeId", e.target.value);
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 9
    }
  })));
}

_s(Home, "G50v2ztIM1xufB8KAxfoD3QGZPU=", false, function () {
  return [_roomservice_react__WEBPACK_IMPORTED_MODULE_2__["useMap"]];
});

_c = Home;

var _c;

$RefreshReg$(_c, "Home");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvaW5kZXgudHN4Il0sIm5hbWVzIjpbIkhvbWUiLCJ1c2VNYXAiLCJmb3JtIiwibWFwIiwidHJlZUlkIiwiZSIsInNldCIsInRhcmdldCIsInZhbHVlIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBRWUsU0FBU0EsSUFBVCxHQUFnQjtBQUFBOztBQUFBLGdCQUNUQyxpRUFBTSxDQUN4QixTQUR3QixFQUV4QixNQUZ3QixDQURHO0FBQUE7QUFBQSxNQUN0QkMsSUFEc0I7QUFBQSxNQUNoQkMsR0FEZ0I7O0FBTTdCLFNBQ0U7QUFBSyxhQUFTLEVBQUMsaUJBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNEVBQ3NFLEdBRHRFLEVBRUU7QUFBRyxRQUFJLEVBQUMsb0RBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRixDQURGLEVBa0JFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsSUFsQkYsRUFvQkU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxrQkFFRTtBQUNFLFNBQUssRUFBRUQsSUFBSSxDQUFDRSxNQURkO0FBRUUsWUFBUSxFQUFFLGtCQUFDQyxDQUFEO0FBQUEsYUFBT0YsR0FBUCxhQUFPQSxHQUFQLHVCQUFPQSxHQUFHLENBQUVHLEdBQUwsQ0FBUyxTQUFULEVBQW9CRCxDQUFDLENBQUNFLE1BQUYsQ0FBU0MsS0FBN0IsQ0FBUDtBQUFBLEtBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxJQUZGLENBcEJGLENBREY7QUE4QkQ7O0dBcEN1QlIsSTtVQUNGQyx5RDs7O0tBREVELEkiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaW5kZXguMDM4YWZjODk3OTYwMTMyNWRkNmUuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZU1hcCB9IGZyb20gXCJAcm9vbXNlcnZpY2UvcmVhY3RcIjtcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gSG9tZSgpIHtcbiAgY29uc3QgW2Zvcm0sIG1hcF0gPSB1c2VNYXA8eyBzZXNzaW9uUGluOiBzdHJpbmc7IHRyZWVJZDogc3RyaW5nIH0+KFxuICAgIFwibXlpbmRleFwiLFxuICAgIFwiaG9tZVwiXG4gICk7XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImludHJvLWNvbnRhaW5lclwiPlxuICAgICAgPHA+XG4gICAgICAgIFRoaXMgaXMgYSBtaW5pbWFsIE5leHQuanMgZXhhbXBsZSB3aXRoIFJvb20gU2VydmljZS4gSXQgZm9sbG93cyB0aGV7XCIgXCJ9XG4gICAgICAgIDxhIGhyZWY9XCJodHRwczovL3Jvb21zZXJ2aWNlLmRldi9kb2NzL3JlYWN0LWdldHRpbmctc3RhcnRlZFwiPlxuICAgICAgICAgIGd1aWRlIGhlcmUuXG4gICAgICAgIDwvYT5cbiAgICAgIDwvcD5cblxuICAgICAgey8qXG4gICAgICA8bGFiZWw+XG4gICAgICAgIFNlc3Npb24gUGluXG4gICAgICAgIDxpbnB1dFxuICAgICAgICAgIHZhbHVlPXtmb3JtLnNlc3Npb25QaW59XG4gICAgICAgICAgb25DaGFuZ2U9eyhlKSA9PiBtYXA/LnNldChcInNlc3Npb25QaW5cIiwgZS50YXJnZXQudmFsdWUpfVxuICAgICAgICAvPlxuICAgICAgPC9sYWJlbD5cbiAgICAgICovfVxuXG4gICAgICA8YnIgLz5cblxuICAgICAgPGxhYmVsPlxuICAgICAgICBMb2FkIFRyZWVcbiAgICAgICAgPGlucHV0XG4gICAgICAgICAgdmFsdWU9e2Zvcm0udHJlZUlkfVxuICAgICAgICAgIG9uQ2hhbmdlPXsoZSkgPT4gbWFwPy5zZXQoXCJ0cnNlZUlkXCIsIGUudGFyZ2V0LnZhbHVlKX1cbiAgICAgICAgLz5cbiAgICAgIDwvbGFiZWw+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwic291cmNlUm9vdCI6IiJ9