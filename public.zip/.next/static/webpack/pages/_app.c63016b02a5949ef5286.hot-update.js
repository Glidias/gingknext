webpackHotUpdate_N_E("pages/_app",{

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./node_modules/@babel/runtime/regenerator */ "./node_modules/@babel/runtime/regenerator/index.js");
/* harmony import */ var C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/extends */ "./node_modules/@babel/runtime/helpers/esm/extends.js");
/* harmony import */ var C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/asyncToGenerator */ "./node_modules/@babel/runtime/helpers/esm/asyncToGenerator.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../styles/globals.css */ "./styles/globals.css");
/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _roomservice_react__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @roomservice/react */ "./node_modules/@roomservice/react/dist/react.esm.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/head */ "./node_modules/next/head.js");
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _util_mockuser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./util/mockuser */ "./pages/util/mockuser.ts");




var _jsxFileName = "C:\\Glenn\\JS\\roomservice\\examples-master\\next.js-minimal\\pages\\_app.tsx",
    _s = $RefreshSig$();


var __jsx = react__WEBPACK_IMPORTED_MODULE_3___default.a.createElement;





function myAuthFunction(_x) {
  return _myAuthFunction.apply(this, arguments);
}

function _myAuthFunction() {
  _myAuthFunction = Object(C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_helpers_esm_asyncToGenerator__WEBPACK_IMPORTED_MODULE_2__["default"])( /*#__PURE__*/C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.mark(function _callee(params) {
    var response, body;
    return C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_regenerator__WEBPACK_IMPORTED_MODULE_0___default.a.wrap(function _callee$(_context) {
      while (1) {
        switch (_context.prev = _context.next) {
          case 0:
            _context.next = 2;
            return fetch("/api/roomservice", {
              method: "POST",
              headers: {
                "Content-Type": "application/json"
              },
              //  Pass cookies to server
              credentials: "include",
              body: JSON.stringify({
                room: params.room,
                //  TODO: Determine userID on server based on cookies or values passed in here.
                user: params.ctx.userID
              })
            });

          case 2:
            response = _context.sent;

            if (!(response.status === 401)) {
              _context.next = 5;
              break;
            }

            throw new Error("Unauthorized!");

          case 5:
            if (!(response.status !== 200)) {
              _context.next = 9;
              break;
            }

            _context.next = 8;
            return response.text();

          case 8:
            throw _context.sent;

          case 9:
            _context.next = 11;
            return response.json();

          case 11:
            body = _context.sent;
            return _context.abrupt("return", {
              user: body.user,
              resources: body.resources,
              token: body.token
            });

          case 13:
          case "end":
            return _context.stop();
        }
      }
    }, _callee);
  }));
  return _myAuthFunction.apply(this, arguments);
}

function MyApp(_ref) {
  _s();

  var Component = _ref.Component,
      pageProps = _ref.pageProps;
  var userID = Object(_util_mockuser__WEBPACK_IMPORTED_MODULE_7__["useUserID"])(); // later see how this would work for deferred connection
  // const [onlineMode, setOnlineMode]  = useState(false);

  return __jsx("div", {
    id: "app-root",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 49,
      columnNumber: 3
    }
  }, __jsx(next_head__WEBPACK_IMPORTED_MODULE_6___default.a, {
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 50,
      columnNumber: 5
    }
  }, __jsx("link", {
    href: "https://fonts.googleapis.com/css2?family=Bitter:ital,wght@0,400;0,700;1,400;1,700&family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&family=Roboto+Mono:wght@400;700&display=swap",
    rel: "stylesheet",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 51,
      columnNumber: 7
    }
  }), __jsx("link", {
    rel: "stylesheet",
    href: "/style.css",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 52,
      columnNumber: 7
    }
  }), __jsx("link", {
    rel: "stylesheet",
    href: "/home.css",
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 53,
      columnNumber: 7
    }
  })), __jsx(_roomservice_react__WEBPACK_IMPORTED_MODULE_5__["RoomServiceProvider"] //  Don't connect until the userID is set
  , {
    online: userID !== null,
    clientParameters: {
      auth: myAuthFunction,
      ctx: {
        userID: userID
      }
    },
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 5
    }
  }, __jsx(Component, Object(C_Glenn_JS_roomservice_examples_master_next_js_minimal_node_modules_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_1__["default"])({}, pageProps, {
    "user-id": userID,
    __self: this,
    __source: {
      fileName: _jsxFileName,
      lineNumber: 65,
      columnNumber: 7
    }
  }))));
}

_s(MyApp, "5mkE3iAD8wVZGOUrxZxWthi7YRs=", false, function () {
  return [_util_mockuser__WEBPACK_IMPORTED_MODULE_7__["useUserID"]];
});

_c = MyApp;
/* harmony default export */ __webpack_exports__["default"] = (MyApp);

var _c;

$RefreshReg$(_c, "MyApp");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvX2FwcC50c3giXSwibmFtZXMiOlsibXlBdXRoRnVuY3Rpb24iLCJwYXJhbXMiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJjcmVkZW50aWFscyIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5Iiwicm9vbSIsInVzZXIiLCJjdHgiLCJ1c2VySUQiLCJyZXNwb25zZSIsInN0YXR1cyIsIkVycm9yIiwidGV4dCIsImpzb24iLCJyZXNvdXJjZXMiLCJ0b2tlbiIsIk15QXBwIiwiQ29tcG9uZW50IiwicGFnZVByb3BzIiwidXNlVXNlcklEIiwiYXV0aCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBRUE7QUFDQTs7U0FFZUEsYzs7Ozs7MlVBQWYsaUJBQThCQyxNQUE5QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUl5QkMsS0FBSyxDQUFDLGtCQUFELEVBQXFCO0FBQy9DQyxvQkFBTSxFQUFFLE1BRHVDO0FBRS9DQyxxQkFBTyxFQUFFO0FBQ1AsZ0NBQWdCO0FBRFQsZUFGc0M7QUFLL0M7QUFDQUMseUJBQVcsRUFBRSxTQU5rQztBQU8vQ0Msa0JBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFMLENBQWU7QUFDbkJDLG9CQUFJLEVBQUVSLE1BQU0sQ0FBQ1EsSUFETTtBQUduQjtBQUNBQyxvQkFBSSxFQUFFVCxNQUFNLENBQUNVLEdBQVAsQ0FBV0M7QUFKRSxlQUFmO0FBUHlDLGFBQXJCLENBSjlCOztBQUFBO0FBSVFDLG9CQUpSOztBQUFBLGtCQW1CTUEsUUFBUSxDQUFDQyxNQUFULEtBQW9CLEdBbkIxQjtBQUFBO0FBQUE7QUFBQTs7QUFBQSxrQkFvQlUsSUFBSUMsS0FBSixDQUFVLGVBQVYsQ0FwQlY7O0FBQUE7QUFBQSxrQkF1Qk1GLFFBQVEsQ0FBQ0MsTUFBVCxLQUFvQixHQXZCMUI7QUFBQTtBQUFBO0FBQUE7O0FBQUE7QUFBQSxtQkF3QmdCRCxRQUFRLENBQUNHLElBQVQsRUF4QmhCOztBQUFBO0FBQUE7O0FBQUE7QUFBQTtBQUFBLG1CQTJCcUJILFFBQVEsQ0FBQ0ksSUFBVCxFQTNCckI7O0FBQUE7QUEyQlFYLGdCQTNCUjtBQUFBLDZDQTRCUztBQUNMSSxrQkFBSSxFQUFFSixJQUFJLENBQUNJLElBRE47QUFFTFEsdUJBQVMsRUFBRVosSUFBSSxDQUFDWSxTQUZYO0FBR0xDLG1CQUFLLEVBQUViLElBQUksQ0FBQ2E7QUFIUCxhQTVCVDs7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxHOzs7O0FBbUNBLFNBQVNDLEtBQVQsT0FBeUM7QUFBQTs7QUFBQSxNQUF4QkMsU0FBd0IsUUFBeEJBLFNBQXdCO0FBQUEsTUFBYkMsU0FBYSxRQUFiQSxTQUFhO0FBQ3ZDLE1BQU1WLE1BQU0sR0FBR1csZ0VBQVMsRUFBeEIsQ0FEdUMsQ0FHdkM7QUFDQTs7QUFFQSxTQUNBO0FBQUssTUFBRSxFQUFDLFVBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFLE1BQUMsZ0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQUNFO0FBQU0sUUFBSSxFQUFDLG1MQUFYO0FBQTJNLE9BQUcsRUFBQyxZQUEvTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBREYsRUFFRTtBQUFNLE9BQUcsRUFBQyxZQUFWO0FBQXVCLFFBQUksRUFBQyxZQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBRkYsRUFHRTtBQUFNLE9BQUcsRUFBQyxZQUFWO0FBQXVCLFFBQUksRUFBQyxXQUE1QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLElBSEYsQ0FERixFQU1FLE1BQUMsc0VBQUQsQ0FDRTtBQURGO0FBRUUsVUFBTSxFQUFFWCxNQUFNLEtBQUssSUFGckI7QUFHRSxvQkFBZ0IsRUFBRTtBQUNoQlksVUFBSSxFQUFFeEIsY0FEVTtBQUVoQlcsU0FBRyxFQUFFO0FBQ0hDLGNBQU0sRUFBTkE7QUFERztBQUZXLEtBSHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsS0FVRSxNQUFDLFNBQUQsNEpBQWVVLFNBQWY7QUFBMEIsZUFBU1YsTUFBbkM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxLQVZGLENBTkYsQ0FEQTtBQXFCRDs7R0EzQlFRLEs7VUFDUUcsd0Q7OztLQURSSCxLO0FBNkJNQSxvRUFBZiIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9fYXBwLmM2MzAxNmIwMmE1OTQ5ZWY1Mjg2LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi9zdHlsZXMvZ2xvYmFscy5jc3NcIjtcbmltcG9ydCB7IFJvb21TZXJ2aWNlUHJvdmlkZXIgfSBmcm9tIFwiQHJvb21zZXJ2aWNlL3JlYWN0XCI7XG5cbmltcG9ydCBIZWFkIGZyb20gJ25leHQvaGVhZCdcbmltcG9ydCB7IHVzZVVzZXJJRCB9IGZyb20gXCIuL3V0aWwvbW9ja3VzZXJcIjtcblxuYXN5bmMgZnVuY3Rpb24gbXlBdXRoRnVuY3Rpb24ocGFyYW1zOiB7XG4gIHJvb206IHN0cmluZztcbiAgY3R4OiB7IHVzZXJJRDogbnVtYmVyIH07XG59KSB7XG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goXCIvYXBpL3Jvb21zZXJ2aWNlXCIsIHtcbiAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgIGhlYWRlcnM6IHtcbiAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgIH0sXG4gICAgLy8gIFBhc3MgY29va2llcyB0byBzZXJ2ZXJcbiAgICBjcmVkZW50aWFsczogXCJpbmNsdWRlXCIsXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgcm9vbTogcGFyYW1zLnJvb20sXG5cbiAgICAgIC8vICBUT0RPOiBEZXRlcm1pbmUgdXNlcklEIG9uIHNlcnZlciBiYXNlZCBvbiBjb29raWVzIG9yIHZhbHVlcyBwYXNzZWQgaW4gaGVyZS5cbiAgICAgIHVzZXI6IHBhcmFtcy5jdHgudXNlcklELFxuICAgIH0pLFxuICB9KTtcblxuICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDEpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmF1dGhvcml6ZWQhXCIpO1xuICB9XG5cbiAgaWYgKHJlc3BvbnNlLnN0YXR1cyAhPT0gMjAwKSB7XG4gICAgdGhyb3cgYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICB9XG5cbiAgY29uc3QgYm9keSA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgcmV0dXJuIHtcbiAgICB1c2VyOiBib2R5LnVzZXIsXG4gICAgcmVzb3VyY2VzOiBib2R5LnJlc291cmNlcyxcbiAgICB0b2tlbjogYm9keS50b2tlbixcbiAgfTtcbn1cblxuZnVuY3Rpb24gTXlBcHAoeyBDb21wb25lbnQsIHBhZ2VQcm9wcyB9KSB7XG4gIGNvbnN0IHVzZXJJRCA9IHVzZVVzZXJJRCgpO1xuXG4gIC8vIGxhdGVyIHNlZSBob3cgdGhpcyB3b3VsZCB3b3JrIGZvciBkZWZlcnJlZCBjb25uZWN0aW9uXG4gIC8vIGNvbnN0IFtvbmxpbmVNb2RlLCBzZXRPbmxpbmVNb2RlXSAgPSB1c2VTdGF0ZShmYWxzZSk7XG5cbiAgcmV0dXJuIChcbiAgPGRpdiBpZD1cImFwcC1yb290XCI+XG4gICAgPEhlYWQ+XG4gICAgICA8bGluayBocmVmPVwiaHR0cHM6Ly9mb250cy5nb29nbGVhcGlzLmNvbS9jc3MyP2ZhbWlseT1CaXR0ZXI6aXRhbCx3Z2h0QDAsNDAwOzAsNzAwOzEsNDAwOzEsNzAwJmFtcDtmYW1pbHk9T3BlbitTYW5zOml0YWwsd2dodEAwLDQwMDswLDcwMDsxLDQwMDsxLDcwMCZhbXA7ZmFtaWx5PVJvYm90bytNb25vOndnaHRANDAwOzcwMCZhbXA7ZGlzcGxheT1zd2FwXCIgcmVsPVwic3R5bGVzaGVldFwiLz5cbiAgICAgIDxsaW5rIHJlbD1cInN0eWxlc2hlZXRcIiBocmVmPVwiL3N0eWxlLmNzc1wiLz5cbiAgICAgIDxsaW5rIHJlbD1cInN0eWxlc2hlZXRcIiBocmVmPVwiL2hvbWUuY3NzXCIvPlxuICAgIDwvSGVhZD5cbiAgICA8Um9vbVNlcnZpY2VQcm92aWRlclxuICAgICAgLy8gIERvbid0IGNvbm5lY3QgdW50aWwgdGhlIHVzZXJJRCBpcyBzZXRcbiAgICAgIG9ubGluZT17dXNlcklEICE9PSBudWxsfVxuICAgICAgY2xpZW50UGFyYW1ldGVycz17e1xuICAgICAgICBhdXRoOiBteUF1dGhGdW5jdGlvbixcbiAgICAgICAgY3R4OiB7XG4gICAgICAgICAgdXNlcklELFxuICAgICAgICB9LFxuICAgICAgfX1cbiAgICA+XG4gICAgICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IHVzZXItaWQ9e3VzZXJJRH0gLz5cbiAgICA8L1Jvb21TZXJ2aWNlUHJvdmlkZXI+XG4gIDwvZGl2PlxuICApO1xufVxuXG5leHBvcnQgZGVmYXVsdCBNeUFwcDtcbiJdLCJzb3VyY2VSb290IjoiIn0=