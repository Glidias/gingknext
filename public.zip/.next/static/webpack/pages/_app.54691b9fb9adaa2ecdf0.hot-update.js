webpackHotUpdate_N_E("pages/_app",{

/***/ "./pages/util/mockuser.ts":
/*!********************************!*\
  !*** ./pages/util/mockuser.ts ***!
  \********************************/
/*! exports provided: userID, setUserID, useUserID */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "userID", function() { return userID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "setUserID", function() { return setUserID; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useUserID", function() { return useUserID; });
/* harmony import */ var nanoid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! nanoid */ "./node_modules/nanoid/index.browser.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
var _s = $RefreshSig$();




var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null),
    userID = _useState[0],
    setUserID = _useState[1];


function useUserID() {
  _s();

  //  useEffect forces this to happen on the client, since `window` is not
  //  available on the server during server-side rendering
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    var userID = window.localStorage.getItem("roomservice-user");

    if (userID == null) {
      var generateBase62ID = Object(nanoid__WEBPACK_IMPORTED_MODULE_0__["customAlphabet"])("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", 22);
      userID = generateBase62ID();
      window.localStorage.setItem("roomservice-user", userID);
    }

    setUserID(userID);
  }, []);
  return userID;
}

_s(useUserID, "OD7bBpZva5O2jO+Puf00hKivP7c=");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvdXRpbC9tb2NrdXNlci50cyJdLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZXJJRCIsInNldFVzZXJJRCIsInVzZVVzZXJJRCIsInVzZUVmZmVjdCIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJnZW5lcmF0ZUJhc2U2MklEIiwiY3VzdG9tQWxwaGFiZXQiLCJzZXRJdGVtIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTs7Z0JBRW1DQSxzREFBUSxDQUFnQixJQUFoQixDO0lBQTdCQyxNO0lBQVFDLFM7OztBQUVmLFNBQVNDLFNBQVQsR0FBb0M7QUFBQTs7QUFFekM7QUFDQTtBQUNBQyx5REFBUyxDQUFDLFlBQU07QUFDZCxRQUFJSCxNQUFNLEdBQUdJLE1BQU0sQ0FBQ0MsWUFBUCxDQUFvQkMsT0FBcEIsQ0FBNEIsa0JBQTVCLENBQWI7O0FBQ0EsUUFBSU4sTUFBTSxJQUFJLElBQWQsRUFBb0I7QUFDbEIsVUFBTU8sZ0JBQWdCLEdBQUdDLDZEQUFjLENBQ3JDLGdFQURxQyxFQUVyQyxFQUZxQyxDQUF2QztBQUlBUixZQUFNLEdBQUdPLGdCQUFnQixFQUF6QjtBQUNBSCxZQUFNLENBQUNDLFlBQVAsQ0FBb0JJLE9BQXBCLENBQTRCLGtCQUE1QixFQUFnRFQsTUFBaEQ7QUFDRDs7QUFDREMsYUFBUyxDQUFDRCxNQUFELENBQVQ7QUFDRCxHQVhRLEVBV04sRUFYTSxDQUFUO0FBYUEsU0FBT0EsTUFBUDtBQUNEOztHQWxCZUUsUyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9fYXBwLjU0NjkxYjlmYjlhZGFhMmVjZGYwLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjdXN0b21BbHBoYWJldCB9IGZyb20gXCJuYW5vaWRcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IFt1c2VySUQsIHNldFVzZXJJRF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuXHJcbmV4cG9ydCBmdW5jdGlvbiB1c2VVc2VySUQoKTogc3RyaW5nIHwgbnVsbCB7XHJcblxyXG4gIC8vICB1c2VFZmZlY3QgZm9yY2VzIHRoaXMgdG8gaGFwcGVuIG9uIHRoZSBjbGllbnQsIHNpbmNlIGB3aW5kb3dgIGlzIG5vdFxyXG4gIC8vICBhdmFpbGFibGUgb24gdGhlIHNlcnZlciBkdXJpbmcgc2VydmVyLXNpZGUgcmVuZGVyaW5nXHJcbiAgdXNlRWZmZWN0KCgpID0+IHtcclxuICAgIGxldCB1c2VySUQgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oXCJyb29tc2VydmljZS11c2VyXCIpO1xyXG4gICAgaWYgKHVzZXJJRCA9PSBudWxsKSB7XHJcbiAgICAgIGNvbnN0IGdlbmVyYXRlQmFzZTYySUQgPSBjdXN0b21BbHBoYWJldChcclxuICAgICAgICBcIjAxMjM0NTY3ODlBQkNERUZHSElKS0xNTk9QUVJTVFVWV1hZWmFiY2RlZmdoaWprbG1ub3BxcnN0dXZ3eHl6XCIsXHJcbiAgICAgICAgMjJcclxuICAgICAgKTtcclxuICAgICAgdXNlcklEID0gZ2VuZXJhdGVCYXNlNjJJRCgpO1xyXG4gICAgICB3aW5kb3cubG9jYWxTdG9yYWdlLnNldEl0ZW0oXCJyb29tc2VydmljZS11c2VyXCIsIHVzZXJJRCk7XHJcbiAgICB9XHJcbiAgICBzZXRVc2VySUQodXNlcklEKTtcclxuICB9LCBbXSk7XHJcblxyXG4gIHJldHVybiB1c2VySUQ7XHJcbn0iXSwic291cmNlUm9vdCI6IiJ9