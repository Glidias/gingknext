webpackHotUpdate_N_E("pages/_app",{

/***/ "./pages/util/mockuser.ts":
/*!********************************!*\
  !*** ./pages/util/mockuser.ts ***!
  \********************************/
/*! exports provided: useUserID */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useUserID", function() { return useUserID; });
/* harmony import */ var nanoid__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! nanoid */ "./node_modules/nanoid/index.browser.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
var _s = $RefreshSig$();



function useUserID() {
  _s();

  var _useState = Object(react__WEBPACK_IMPORTED_MODULE_1__["useState"])(null),
      userID = _useState[0],
      setUserID = _useState[1]; //  useEffect forces this to happen on the client, since `window` is not
  //  available on the server during server-side rendering


  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(function () {
    var userID = window.localStorage.getItem("roomservice-user");

    if (userID == null) {
      var generateBase62ID = Object(nanoid__WEBPACK_IMPORTED_MODULE_0__["customAlphabet"])("0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz", 22);
      userID = generateBase62ID();
      window.localStorage.setItem("roomservice-user", userID);
    }

    setUserID(userID);
  }, []);
  return userID;
}

_s(useUserID, "/A8xugblcuKEFcxbd5cEoSwn/aI=");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vcGFnZXMvdXRpbC9tb2NrdXNlci50cyJdLCJuYW1lcyI6WyJ1c2VVc2VySUQiLCJ1c2VTdGF0ZSIsInVzZXJJRCIsInNldFVzZXJJRCIsInVzZUVmZmVjdCIsIndpbmRvdyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJnZW5lcmF0ZUJhc2U2MklEIiwiY3VzdG9tQWxwaGFiZXQiLCJzZXRJdGVtIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFJTyxTQUFTQSxTQUFULEdBQW9DO0FBQUE7O0FBQUEsa0JBQ2JDLHNEQUFRLENBQWdCLElBQWhCLENBREs7QUFBQSxNQUNsQ0MsTUFEa0M7QUFBQSxNQUMxQkMsU0FEMEIsaUJBRXpDO0FBQ0E7OztBQUNBQyx5REFBUyxDQUFDLFlBQU07QUFDZCxRQUFJRixNQUFNLEdBQUdHLE1BQU0sQ0FBQ0MsWUFBUCxDQUFvQkMsT0FBcEIsQ0FBNEIsa0JBQTVCLENBQWI7O0FBQ0EsUUFBSUwsTUFBTSxJQUFJLElBQWQsRUFBb0I7QUFDbEIsVUFBTU0sZ0JBQWdCLEdBQUdDLDZEQUFjLENBQ3JDLGdFQURxQyxFQUVyQyxFQUZxQyxDQUF2QztBQUlBUCxZQUFNLEdBQUdNLGdCQUFnQixFQUF6QjtBQUNBSCxZQUFNLENBQUNDLFlBQVAsQ0FBb0JJLE9BQXBCLENBQTRCLGtCQUE1QixFQUFnRFIsTUFBaEQ7QUFDRDs7QUFDREMsYUFBUyxDQUFDRCxNQUFELENBQVQ7QUFDRCxHQVhRLEVBV04sRUFYTSxDQUFUO0FBYUEsU0FBT0EsTUFBUDtBQUNEOztHQWxCZUYsUyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9fYXBwLjkzMmU4M2JkYjcwNzFmMDdhODBmLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBjdXN0b21BbHBoYWJldCB9IGZyb20gXCJuYW5vaWRcIjtcclxuaW1wb3J0IHsgdXNlRWZmZWN0LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5cclxuXHJcblxyXG5leHBvcnQgZnVuY3Rpb24gdXNlVXNlcklEKCk6IHN0cmluZyB8IG51bGwge1xyXG4gIGNvbnN0IFt1c2VySUQsIHNldFVzZXJJRF0gPSB1c2VTdGF0ZTxzdHJpbmcgfCBudWxsPihudWxsKTtcclxuICAvLyAgdXNlRWZmZWN0IGZvcmNlcyB0aGlzIHRvIGhhcHBlbiBvbiB0aGUgY2xpZW50LCBzaW5jZSBgd2luZG93YCBpcyBub3RcclxuICAvLyAgYXZhaWxhYmxlIG9uIHRoZSBzZXJ2ZXIgZHVyaW5nIHNlcnZlci1zaWRlIHJlbmRlcmluZ1xyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBsZXQgdXNlcklEID0gd2luZG93LmxvY2FsU3RvcmFnZS5nZXRJdGVtKFwicm9vbXNlcnZpY2UtdXNlclwiKTtcclxuICAgIGlmICh1c2VySUQgPT0gbnVsbCkge1xyXG4gICAgICBjb25zdCBnZW5lcmF0ZUJhc2U2MklEID0gY3VzdG9tQWxwaGFiZXQoXHJcbiAgICAgICAgXCIwMTIzNDU2Nzg5QUJDREVGR0hJSktMTU5PUFFSU1RVVldYWVphYmNkZWZnaGlqa2xtbm9wcXJzdHV2d3h5elwiLFxyXG4gICAgICAgIDIyXHJcbiAgICAgICk7XHJcbiAgICAgIHVzZXJJRCA9IGdlbmVyYXRlQmFzZTYySUQoKTtcclxuICAgICAgd2luZG93LmxvY2FsU3RvcmFnZS5zZXRJdGVtKFwicm9vbXNlcnZpY2UtdXNlclwiLCB1c2VySUQpO1xyXG4gICAgfVxyXG4gICAgc2V0VXNlcklEKHVzZXJJRCk7XHJcbiAgfSwgW10pO1xyXG5cclxuICByZXR1cm4gdXNlcklEO1xyXG59Il0sInNvdXJjZVJvb3QiOiIifQ==