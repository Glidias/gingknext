import { useMap } from "@roomservice/react"
import Link from 'next/link'

export default function Home() {
  const [form, map] = useMap<{ sessionPin: string; treeId: string }>(
    "myindex",
    "home"
  );

  return (
    <div className="intro-container">

      {/*
      <label>
        Session Pin
        <input
          value={form.sessionPin}
          onChange={(e) => map?.set("sessionPin", e.target.value)}
        />
      </label>
      */}

      <br />

      <label>
        Tree ID
        <input
          value={form.treeId}
          onChange={(e) => map?.set("treeId", e.target.value)}
        />
      </label>
      <Link href={`room/${form.treeId}`}>Load</Link>
    </div>
  );
}
