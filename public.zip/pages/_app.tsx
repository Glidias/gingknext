import "../styles/globals.css";
import { RoomServiceProvider } from "@roomservice/react";

import Head from 'next/head'
import { useUserID } from "./util/mockuser";

import {createContext} from "react"
const AppContext = createContext('app');

async function myAuthFunction(params: {
  room: string;
  ctx: { userID: number };
}) {
  const response = await fetch("/api/roomservice", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    //  Pass cookies to server
    credentials: "include",
    body: JSON.stringify({
      room: params.room,

      //  TODO: Determine userID on server based on cookies or values passed in here.
      user: params.ctx.userID,
    }),
  });

  if (response.status === 401) {
    throw new Error("Unauthorized!");
  }

  if (response.status !== 200) {
    throw await response.text();
  }

  const body = await response.json();
  return {
    user: body.user,
    resources: body.resources,
    token: body.token,
  };
}

function MyApp({ Component, pageProps }) {
  const userID = useUserID();
  // AppContext.userID = userID;
  // later see how this would work for deferred connection
  // const [onlineMode, setOnlineMode]  = useState(false);

  return (
  <AppContext.Provider value="app">
    <div id="app-root">
      <Head>
        <link href="https://fonts.googleapis.com/css2?family=Bitter:ital,wght@0,400;0,700;1,400;1,700&amp;family=Open+Sans:ital,wght@0,400;0,700;1,400;1,700&amp;family=Roboto+Mono:wght@400;700&amp;display=swap" rel="stylesheet"/>
        <link rel="stylesheet" href="/style.css"/>
        <link rel="stylesheet" href="/home.css"/>
      </Head>
      <RoomServiceProvider
        //  Don't connect until the userID is set
        online={userID !== null}
        clientParameters={{
          auth: myAuthFunction,
          ctx: {
            userID,
          },
        }}
      >
        <Component {...pageProps} />
      </RoomServiceProvider>
    </div>
  </AppContext.Provider>
  );
}

export default MyApp;
