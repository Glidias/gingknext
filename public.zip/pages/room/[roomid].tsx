import { useMap } from "@roomservice/react";
import Doc from "../../components/doc";

export default function Room({query}) {
  const userID = this.context.userID;
  return (
    <div>
      {userID}
      <Doc></Doc>
    </div>
  );
}
